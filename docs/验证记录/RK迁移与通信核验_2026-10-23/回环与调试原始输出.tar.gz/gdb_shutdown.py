import os
import pathlib
import signal
import subprocess
import time

base = pathlib.Path('/home/jcfh/.cache/uav1018-validation-20261023')
environment = dict(os.environ)
environment['ROS_IP'] = '127.0.0.1'
environment['ROS_MASTER_URI'] = 'http://127.0.0.1:11324'
environment['ROS_LOG_DIR'] = str(base / 'gdb-ros-logs')
environment['ROS_HOME'] = str(base / 'gdb-ros-home')
environment['LD_LIBRARY_PATH'] = str(base / 'debug/usr/lib/aarch64-linux-gnu') + ':' + environment.get('LD_LIBRARY_PATH', '')
for key in ('ROS_HOSTNAME', 'ROS_NAMESPACE'):
    environment.pop(key, None)
master = debugger = None
try:
    with (base / 'gdb-roscore.log').open('wb') as log:
        master = subprocess.Popen(['roscore', '-p', '11324'], env=environment,
                                  stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    time.sleep(2)
    command = [str(base / 'debug/usr/bin/gdb'), '-batch', '-ex', 'set pagination off',
               '-ex', 'set confirm off', '-ex', 'handle SIGINT nostop noprint pass',
               '-ex', 'run', '-ex', 'thread apply all bt', '--args',
               '/home/jcfh/catkin_ws/devel/lib/location/location_node',
               '__name:=location_shutdown_probe', '__ns:=/rk_validation/gdb',
               '_is_simulation:=true', '_use_tf_mini:=false',
               '/tf:=/rk_validation/gdb/tf', '/tf_static:=/rk_validation/gdb/tf_static',
               '/mavros/vision_pose/pose:=/rk_validation/gdb/pose']
    with (base / 'location-shutdown-gdb.txt').open('wb') as log:
        debugger = subprocess.Popen(command, env=environment, stdout=log,
                                    stderr=subprocess.STDOUT, start_new_session=True)
        time.sleep(4)
        children_path = pathlib.Path('/proc/{0}/task/{0}/children'.format(debugger.pid))
        children = children_path.read_text().strip().split()
        candidates = [int(pid) for pid in children if pathlib.Path('/proc/' + pid + '/comm').read_text().strip() == 'location_node']
        if len(candidates) != 1:
            raise RuntimeError('Expected one debugger inferior, got ' + str(candidates))
        os.kill(candidates[0], signal.SIGINT)
        debugger.wait(timeout=20)
    print((base / 'location-shutdown-gdb.txt').read_text(errors='replace'))
finally:
    for child in (debugger, master):
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGINT)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
