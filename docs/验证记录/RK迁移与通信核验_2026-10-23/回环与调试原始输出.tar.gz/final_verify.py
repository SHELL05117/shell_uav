from __future__ import print_function
import hashlib
import json
import os
import subprocess
import sys

base = '/home/jcfh/.cache/uav1018-validation-20261023'
workspace = '/home/jcfh/catkin_ws'
with open(base + '/source_manifest.json') as handle:
    manifest = json.load(handle)
expected = dict(manifest['files'])
expected.update(manifest['deployed_updates'])
mismatches = []
for name, digest in sorted(expected.items()):
    with open(workspace + '/' + name, 'rb') as handle:
        actual = hashlib.sha256(handle.read()).hexdigest()
    if actual != digest:
        mismatches.append(name)
targets = [
    'location/location_node', 'location/tfmini_test',
    'rplidar_ros/rplidarNode', 'rplidar_ros/rplidarNodeClient',
    'ego_planner_2d/ego_planner_2d_node',
    'navigation_2d/rescue_mission_node',
    'navigation_2d/ego_trajectory_controller_node',
    'servo_control/servo_controller_node',
    'gc_2026_sim/gazebo_simulation_vehicle_node',
    'gc_2026_sim/px4_sensor_rig_node']
binary_checks = []
for target in targets:
    path = workspace + '/devel/lib/' + target
    output = subprocess.check_output(['ldd', path], stderr=subprocess.STDOUT)
    passed = os.access(path, os.X_OK) and b'not found' not in output
    with open(path, 'rb') as handle:
        elf = handle.read(20)
    passed = passed and elf[:4] == b'\x7fELF' and elf[18:20] == b'\xb7\x00'
    binary_checks.append({'target': target, 'aarch64_elf_and_links_ok': passed,
                          'ldd': output.decode('utf-8', 'replace')})
result = {'passed': not mismatches and all(x['aarch64_elf_and_links_ok'] for x in binary_checks),
          'source_files_verified': len(expected), 'source_mismatches': mismatches,
          'source_updates': manifest['deployed_updates'], 'executables': binary_checks,
          'jetson_detector_present': os.path.exists(workspace + '/devel/lib/ssd_detection/ssd_detection_node'),
          'scope': '7 packages, 10 non-Jetson executables; no inference/hardware acceptance'}
with open(base + '/final-source-and-binaries.json', 'w') as handle:
    json.dump(result, handle, indent=2)
print(json.dumps(result, sort_keys=True))
sys.exit(0 if result['passed'] else 1)
